import React, { Component } from 'react';
import { Field, reduxForm } from 'redux-form';
import { connect } from 'react-redux';
import { createPost } from '../actions/index';
import { bindActionCreators } from 'redux';

//1° first create component to display form
class PostNew extends Component {
	
	render() {
		const { handleSubmit } = this.props;

		return (
			<form onSubmit={handleSubmit(this.props.createPost)}>
				<h3>Create a new Post</h3>
				<div className="form-group">
					<label>Title</label>
					<input name="title"	type="text" className="form-control"/>
				</div>
				<div className="form-group">
					<label>Categories</label>
					<input name="categories" type="text" className="form-control"/>
				</div>
				<div clinputassName="form-group">
					<label>Content</label>
					<textarea name="content" className="form-control"/>
				</div>

				<button type="submit" className="btn btn-primary">Submit</button>
			</form>
		);
	}
}

/*export default reduxForm({
	form: 'PostNew',
	fields: ['title', 'categories', 'content']
})(PostNew);
*/

/*export default reduxForm({
	form: 'PostNew',
	fields: ['title', 'categories', 'content']
})(PostNew);*/

function mapDispatchToProps(dispatch) {
	return bindActionCreators({ createPost }, dispatch);
}

var MyPostForm = reduxForm({
	form: 'PostNew',
})(PostNew)

MyPostForm = connect(null, mapDispatchToProps)(MyPostForm)

export default MyPostForm;