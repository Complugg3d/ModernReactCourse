import React, { Component } from 'react';
import { connect } from 'react-redux';
import { fetchPosts } from '../actions/index';
import { Link } from 'react-router';

class PostIndex extends Component {
	componentWillMount() {
		this.props.fetchPosts();
	}
	//Link is an anchor tag mado to respond to react routes
	render() {
		return (
			<div>
				<div className="text-xs-right">

					<Link to="/posts/new" className="btn btn-primary">
						Add a Post
					</Link>
				</div>
				List of blog posts.
			</div>
		);
	}
}



export default connect(null, { fetchPosts })(PostIndex);